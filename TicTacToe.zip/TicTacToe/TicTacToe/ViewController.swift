//
//  ViewController.swift
//  TicTacToe
//
//  Created by Will kaminski on 7/17/17.
//  Copyright © 2017 Will kaminski. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var webview: UIWebView!
    
    @IBOutlet weak var Winner: UILabel!
    
    //Buttons
    @IBAction func Buttonbr(_ sender: Any) {
    }
    @IBOutlet weak var Buttonbr1: UIButton!
    
    @IBAction func Buttonbm(_ sender: Any) {
    }
    @IBOutlet weak var Buttonbm1: UIButton!
    
    @IBAction func Buttonbl(_ sender: Any) {
    }
    @IBOutlet weak var Buttonbl1: UIButton!
    
    @IBAction func Buttonmr(_ sender: Any) {
    }
    @IBOutlet weak var Buttonmr1: UIButton!
    
    @IBAction func Buttonm(_ sender: Any) {
    }
    @IBOutlet weak var Buttonm1: UIButton!
    
    @IBAction func Buttonml(_ sender: Any) {
    }
    @IBOutlet weak var Buttonml1: UIButton!
    
    @IBAction func Buttontr(_ sender: Any) {
    }
    @IBOutlet weak var Buttontr1: UIButton!
    
    @IBAction func Buttontm(_ sender: Any) {
    }
    @IBOutlet weak var Buttontm1: UIButton!
    
    @IBAction func Buttontl(_ sender: Any) {
    }
    @IBOutlet weak var Buttontl1: UIButton!
    //Buttons
    
    let X = "X"
    
    let O = "O"
    
    var Gameover = false
    
    
    
    
    
    
    
    
    //X and O buttons
        
    
        
    @IBAction func Obutton(_ sender: Any)
    {
        while Gameover == false
         {
        if (sender as AnyObject).tag == 1
      {
            Buttontl1.setTitle("/(O)", for: UIControlState.normal)
      }
        else if (sender as AnyObject).tag == 2
      {
            Buttontm1.setTitle("/(O)", for: UIControlState.normal)
      }
        else if (sender as AnyObject).tag == 3
      {
            Buttontr1.setTitle("/(O)", for: UIControlState.normal)
      }
        else if (sender as AnyObject).tag == 4
      {
            Buttonml1.setTitle("/(O)", for: UIControlState.normal)
      }
        else if (sender as AnyObject).tag == 5
      {
            Buttonm1.setTitle("/(O)", for: UIControlState.normal)
      }
        else if (sender as AnyObject).tag == 6
      {
            Buttonmr1.setTitle("/(O)", for: UIControlState.normal)
      }
        else if (sender as AnyObject).tag == 7
      {
            Buttonbl1.setTitle("/(O)", for: UIControlState.normal)
      }
        else if (sender as AnyObject).tag == 8
      {
            Buttonbm1.setTitle("/(O)", for: UIControlState.normal)
      }
        else if (sender as AnyObject).tag == 9
      {
            Buttonbr1.setTitle("/(O)", for: UIControlState.normal)
      }
    }
}
        
    @IBAction func Xbutton(_ sender: Any)
    {
         while Gameover == false
         {
        if (sender as AnyObject).tag == 1
        {
           Buttontl1.setTitle("/(X)", for: UIControlState.normal)
        }
        else if (sender as AnyObject).tag == 2
        {
            Buttontm1.setTitle("/(X)", for: UIControlState.normal)
        }
        else if (sender as AnyObject).tag == 3
        {
            Buttontr1.setTitle("/(X)", for: UIControlState.normal)
        }
        else if (sender as AnyObject).tag == 4
        {
            Buttonml1.setTitle("/(X)", for: UIControlState.normal)
        }
        else if (sender as AnyObject).tag == 5
        {
            Buttonm1.setTitle("/(X)", for: UIControlState.normal)
        }
        else if (sender as AnyObject).tag == 6
        {
            Buttonmr1.setTitle("/(X)", for: UIControlState.normal)
        }
        else if (sender as AnyObject).tag == 7
        {
            Buttonbl1.setTitle("/(X)", for: UIControlState.normal)
        }
        else if (sender as AnyObject).tag == 8
        {
            Buttonbm1.setTitle("/(X)", for: UIControlState.normal)
        }
        else if (sender as AnyObject).tag == 9
        {
            Buttonbr1.setTitle("/(X)", for: UIControlState.normal)
        }
    }
}
    
        
    //X and O buttons
        
        
        
    
    
    @IBAction func Reset(_ sender: Any)
    {
        Buttontl1.setTitle(" ", for: UIControlState.normal)
        Buttontm1.setTitle(" ", for: UIControlState.normal)
        Buttontr1.setTitle(" ", for: UIControlState.normal)
        Buttonml1.setTitle(" ", for: UIControlState.normal)
        Buttonm1.setTitle(" ", for: UIControlState.normal)
        Buttonmr1.setTitle(" ", for: UIControlState.normal)
        Buttonbl1.setTitle(" ", for: UIControlState.normal)
        Buttonbm1.setTitle(" ", for: UIControlState.normal)
        Buttonbr1.setTitle(" ", for: UIControlState.normal)
        Winner.text = (" ")
    }
            
        
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        while Gameover == false
        {
        //Winner X
        if Buttontl1.currentTitle == "X" && Buttontm1.currentTitle == "X" && Buttontr1.currentTitle == "X"
        {
            Winner.text = "Player X wins!"
            Gameover = true
        }
        else if Buttonml1.currentTitle == "X" && Buttonm1.currentTitle == "X" && Buttonmr1.currentTitle == "X"
        {
            Winner.text = "Player X wins!"
            Gameover = true
        }
        else if Buttonbl1.currentTitle == "X" && Buttonbm1.currentTitle == "X" && Buttonbr1.currentTitle == "X"
        {
            Winner.text = "Player X wins!"
            Gameover = true
        }
        else if Buttontl1.currentTitle == "X" && Buttonml1.currentTitle == "X" && Buttonbl1.currentTitle == "X"
        {
            Winner.text = "Player X wins!"
            Gameover = true
        }
        else if Buttontm1.currentTitle == "X" && Buttonm1.currentTitle == "X" && Buttonbm1.currentTitle == "X"
        {
            Winner.text = "Player X wins!"
            Gameover = true
        }
        else if Buttontr1.currentTitle == "X" && Buttonmr1.currentTitle == "X" && Buttonbr1.currentTitle == "X"
        {
            Winner.text = "Player X wins!"
            Gameover = true
        }
        else if Buttontl1.currentTitle == "X" && Buttonm1.currentTitle == "X" && Buttonbr1.currentTitle == "X"
        {
            Winner.text = "Player X wins!"
            Gameover = true
        }
        else if Buttontr1.currentTitle == "X" && Buttonm1.currentTitle == "X" && Buttonbl1.currentTitle == "X"
        {
            Winner.text = "Player X wins!"
            Gameover = true
        }
        // Winner X
        
        // Winner O
        if Buttontl1.currentTitle == "O" && Buttontm1.currentTitle == "O" && Buttontr1.currentTitle == "O"
        {
            Winner.text = "Player O wins!"
            Gameover = true
        }
        else if Buttonml1.currentTitle == "O" && Buttonm1.currentTitle == "O" && Buttonmr1.currentTitle == "O"
        {
            Winner.text = "Player O wins!"
            Gameover = true
        }
        else if Buttonbl1.currentTitle == "O" && Buttonbm1.currentTitle == "O" && Buttonbr1.currentTitle == "O"
        {
            Winner.text = "Player O wins!"
            Gameover = true
        }
        else if Buttontl1.currentTitle == "O" && Buttonml1.currentTitle == "O" && Buttonbl1.currentTitle == "O"
        {
            Winner.text = "Player O wins!"
            Gameover = true
        }
        else if Buttontm1.currentTitle == "O" && Buttonm1.currentTitle == "O" && Buttonbm1.currentTitle == "O"
        {
            Winner.text = "Player O wins!"
            Gameover = true
        }
        else if Buttontr1.currentTitle == "O" && Buttonmr1.currentTitle == "O" && Buttonbr1.currentTitle == "O"
        {
            Winner.text = "Player O wins!"
            Gameover = true
        }
        else if Buttontl1.currentTitle == "O" && Buttonm1.currentTitle == "O" && Buttonbr1.currentTitle == "O"
        {
            Winner.text = "Player O wins!"
            Gameover = true
        }
        else if Buttontr1.currentTitle == "O" && Buttonm1.currentTitle == "O" && Buttonbl1.currentTitle == "O"
        {
            Winner.text = "Player O wins!"
            Gameover = true
        }
        // Winner O
    }
        
        let url = NSURL(string: "http://www.sweetoothdesign.com/games-tic-tac-toe")!
        let request = NSURLRequest(url: url as URL)
        webview.loadRequest(request as URLRequest)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


